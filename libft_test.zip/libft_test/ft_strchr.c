/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:41:33 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:41:39 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to locate the first occurrence of character 'c' in string 's'
char *ft_strchr(const char *s, int c)
{
    while (*s && *s != (char)c)  // Loop through the string 's' until 'c' or the end of the string is found
        s++;  // Move to the next character in 's'

    if (*s == (char)c || !c)  // Check if 'c' is found or if 'c' is null (end-of-string marker)
        return ((char *)s);  // Return a pointer to the location of 'c' in 's'

    return (NULL);  // If 'c' is not found and not null, return NULL to indicate it's not in 's'
}

#include <stdio.h>
#include <string.h>  // Include the standard library for the 'strchr' function

int main()
{
    // Input string
    char input[] = "Hello, World!";
    
    // Character to search for
    char target = 'W';

    // Call ft_strchr to find the first occurrence of 'target' in 'input'
    char *result = ft_strchr(input, target);

    if (result)
    {
        // Calculate the index of 'target' in 'input' by subtracting 'result' from 'input'
        int index = result - input;

        printf("Character '%c' found at index %d\n", target, index);
        // Should print "Character 'W' found at index 7"
    }
    else
    {
        printf("Character '%c' not found\n", target);
    }

    return 0;
}
/*Character 'W' found at index 7
*/