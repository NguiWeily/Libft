/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:44:44 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:44:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to convert a lowercase character to uppercase if it is a lowercase letter
int ft_toupper(int c)
{
    if (c >= 'a' && c <= 'z')  // Check if 'c' is a lowercase letter (ASCII values)
    {
        return (c - 32);  // If 'c' is lowercase, subtract 32 from its ASCII value to convert to uppercase
    }
    return (c);  // If 'c' is not a lowercase letter, return it unchanged
}

#include <stdio.h>

int main()
{
    // Test characters
    char lowerCaseChar = 'a';  // Lowercase 'a'
    char nonLowerCaseChar = 'X';  // A non-lowercase character

    // Call ft_toupper to convert 'lowerCaseChar' to uppercase
    int result1 = ft_toupper(lowerCaseChar);

    // Call ft_toupper with a non-lowercase character (should remain unchanged)
    int result2 = ft_toupper(nonLowerCaseChar);

    printf("Result 1: %c\n", result1);
    printf("Result 2: %c\n", result2);

    return 0;
}

/*Result 1: A
Result 2: X
*/