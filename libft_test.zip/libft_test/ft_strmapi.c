/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:41:35 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:41:38 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to apply a given function 'f' to each character in a string 's' with its index and return a new string
char *ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
    size_t len;   // Length of the input string 's'
    char *result;  // Pointer to the result string
    int i;         // Index variable for iterating through 's'

    if (!s || !f)  // Check if 's' or 'f' is NULL
        return (NULL);  // If either is NULL, return NULL

    i = 0;         // Initialize the index to 0
    len = ft_strlen(s);  // Calculate the length of the input string 's'

    // Allocate memory for the result string with a size of 'len + 1' (for the null terminator)
    result = (char *)malloc(sizeof(char) * (len + 1));

    if (!result)  // Check if memory allocation failed
        return (NULL);  // If allocation failed, return NULL

    while (s[i])  // Loop through the input string 's'
    {
        result[i] = f(i, s[i]);  // Apply the function 'f' to the current character with its index
        i++;  // Increment the index to move to the next character in 's'
    }

    result[i] = '\0';  // Ensure that the result string is null-terminated

    return (result);  // Return a pointer to the newly created result string
}

#include <stdio.h>

// Function to convert characters to uppercase
char convert_to_uppercase(unsigned int index, char c)
{
    // Check if the character is lowercase and convert it to uppercase
    if (c >= 'a' && c <= 'z')
        return c - ('a' - 'A');
    return c;
}

int main()
{
    // Input string
    const char input[] = "Hello, World!";

    // Call ft_strmapi to convert the input string to uppercase
    char *result = ft_strmapi(input, convert_to_uppercase);

    printf("Original String: %s\n", input);
    printf("Modified String: %s\n", result);

    // Free the memory allocated for the result string
    free(result);

    return 0;
}

/*Original String: Hello, World!
Modified String: HELLO, WORLD!
*/