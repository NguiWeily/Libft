/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:26:11 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:26:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int ft_isalpha(int c) {
    // Check if the character is an uppercase or lowercase letter
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

#include <stdio.h>

int main() {
    char test_char1 = 'A'; // Uppercase letter
    char test_char2 = 'a'; // Lowercase letter
    char test_char3 = '5'; // Digit
    char test_char4 = '$'; // Special character

    // Check if the characters are alphabetic using ft_isalpha
    if (ft_isalpha(test_char1)) {
        printf("%c is an alphabetic character.\n", test_char1);
    } else {
        printf("%c is not an alphabetic character.\n", test_char1);
    }

    if (ft_isalpha(test_char2)) {
        printf("%c is an alphabetic character.\n", test_char2);
    } else {
        printf("%c is not an alphabetic character.\n", test_char2);
    }

    if (ft_isalpha(test_char3)) {
        printf("%c is an alphabetic character.\n", test_char3);
    } else {
        printf("%c is not an alphabetic character.\n", test_char3);
    }

    if (ft_isalpha(test_char4)) {
        printf("%c is an alphabetic character.\n", test_char4);
    } else {
        printf("%c is not an alphabetic character.\n", test_char4);
    }

    return 0;
}
/* In this main function:

We declare four character variables (test_char1, test_char2, test_char3, and test_char4) with different characters for testing.

We use the ft_isalpha function to check if each character is an alphabetic character.

For each character, we print a message indicating whether it is an alphabetic character or not based on the result of the ft_isalpha function.

The output will indicate whether each character is alphabetic or not based on the definition provided by the ft_isalpha function.

This test code demonstrates how to use the ft_isalpha function to check if a character is an alphabetic letter.
*/
