/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:26:11 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:26:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int ft_isalpha(int c) {
    // Check if the character is an uppercase or lowercase letter
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

#include <stdio.h>

int main() {
    char test_char1 = 'A'; // Uppercase letter
    char test_char2 = 'a'; // Lowercase letter
    char test_char3 = '5'; // Digit
    char test_char4 = '$'; // Special character

    // Check if the characters are alphabetic using ft_isalpha
    if (ft_isalpha(test_char1)) {
        printf("%c is an alphabetic character.\n", test_char1);
    } else {
        printf("%c is not an alphabetic character.\n", test_char1);
    }

    if (ft_isalpha(test_char2)) {
        printf("%c is an alphabetic character.\n", test_char2);
    } else {
        printf("%c is not an alphabetic character.\n", test_char2);
    }

    if (ft_isalpha(test_char3)) {
        printf("%c is an alphabetic character.\n", test_char3);
    } else {
        printf("%c is not an alphabetic character.\n", test_char3);
    }

    if (ft_isalpha(test_char4)) {
        printf("%c is an alphabetic character.\n", test_char4);
    } else {
        printf("%c is not an alphabetic character.\n", test_char4);
    }

    return 0;
}
/*A is an alphabetic character.
a is an alphabetic character.
5 is not an alphabetic character.
$ is not an alphabetic character.
*/