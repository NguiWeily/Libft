/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdelone.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:32:04 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:32:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to delete a single node in a linked list and its content using a provided deletion function
void ft_lstdelone(t_list *lst, void (*del)(void *))
{
    // Check if the node or the deletion function is NULL
    if (!lst || !del)
        return;

    // Delete the content of the node using the provided deletion function
    del(lst->content);

    // Free the memory allocated for the node itself
    free(lst);
}

// A sample deletion function that frees the memory of a string
void free_string(void *content)
{
    free(content);
}

int main()
{
    // Create a linked list node with string content
    t_list *node = ft_lstnew(ft_strdup("Node data"));

    // Delete the node and its content using the ft_lstdelone function
    ft_lstdelone(node, free_string);

    // Verify that the node is deleted (node is NULL)
    if (node == NULL)
    {
        printf("The node is deleted.\n"); // Should print "The node is deleted."
    }

    return 0;
}
