/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:21:00 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:21:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h" which likely contains function prototypes and necessary includes for this function.

int ft_atoi(const char *str)
{
    int sign;    // Initialize a variable 'sign' to store the sign of the number (positive or negative).
    int value;   // Initialize a variable 'value' to store the numeric value of the string.

    sign = 1;    // Default sign is positive.
    value = 0;   // Initialize the value to 0.

    // Skip leading whitespace characters (spaces and control characters) in the input string.
    while (*str == ' ' || (*str >= '\t' && *str <= '\r'))
        str++;

    // Check for a '+' or '-' sign at the beginning of the string and update 'sign' accordingly.
    if (*str == '-' || *str == '+')
        sign = 44 - *str++;  // If '-' is encountered, sign becomes -1, if '+' is encountered, sign remains 1.

    // Parse the digits in the string and convert them to an integer value.
    while (ft_isdigit(*str))  // Loop while the current character is a digit.
    {
        value = value * 10 + (*str++ - '0'); // Convert the digit character to its numeric value and update 'value'.
    }

    return (sign * value); // Return the final integer value with the correct sign.
}


#include <stdio.h>

int main() {
    // Test cases
    const char *str1 = "12345";
    const char *str2 = "-6789";
    const char *str3 = "   42";
    const char *str4 = "invalid123";

    // Convert and print the results
    int result1 = ft_atoi(str1);
    int result2 = ft_atoi(str2);
    int result3 = ft_atoi(str3);
    int result4 = ft_atoi(str4);

    printf("Result 1: %d\n", result1); // Should print "Result 1: 12345"
    printf("Result 2: %d\n", result2); // Should print "Result 2: -6789"
    printf("Result 3: %d\n", result3); // Should print "Result 3: 42"
    printf("Result 4: %d\n", result4); // Should print "Result 4: 0" (due to the invalid input)

    return 0;
}