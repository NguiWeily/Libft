/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:21:00 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:21:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int ft_atoi(const char *str)
{
    int sign;
    int value;

    // Initialize sign and value
    sign = 1;
    value = 0;

    // Skip leading whitespace characters
    while (*str == ' ' || (*str >= '\t' && *str <= '\r'))
        str++;

    // Handle optional sign (+ or -)
    if (*str == '-' || *str == '+') {
        // Set sign based on the character
        sign = (*str == '-') ? -1 : 1;
        // Move to the next character
        str++;
    }

    // Parse digits and calculate the integer value
    while (ft_isdigit(*str)) {
        value = value * 10 + (*str - '0');
        str++;
    }

    // Apply the sign to the final value and return it
    return (sign * value);
}

#include <stdio.h>

int main() {
    // Test cases
    const char *str1 = "12345";
    const char *str2 = "-6789";
    const char *str3 = "   42";
    const char *str4 = "invalid123";

    // Convert and print the results
    int result1 = ft_atoi(str1);
    int result2 = ft_atoi(str2);
    int result3 = ft_atoi(str3);
    int result4 = ft_atoi(str4);

    printf("Result 1: %d\n", result1); // Should print "Result 1: 12345"
    printf("Result 2: %d\n", result2); // Should print "Result 2: -6789"
    printf("Result 3: %d\n", result3); // Should print "Result 3: 42"
    printf("Result 4: %d\n", result4); // Should print "Result 4: 0" (due to the invalid input)

    return 0;
}