/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putendl_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:38:49 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:38:53 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to write a string 's' followed by a newline character to a specified file descriptor 'fd'
void ft_putendl_fd(char *s, int fd)
{
    if (!s)  // Check if the input string 's' is NULL
        return ;  // If 's' is NULL, return without doing anything

    // Use the 'write' system call to write the string 's' to 'fd' followed by a newline character
    write(fd, s, ft_strlen(s));  // Write the string 's'
    write(fd, "\n", 1);  // Write a newline character '\n'
}

#include <stdio.h>
#include <unistd.h>  // Include the standard library for the 'write' function

int main()
{
    // File descriptor for standard output (stdout)
    int fd = 1;

    // Call ft_putendl_fd to write a string to stdout followed by a newline
    ft_putendl_fd("Hello, World!", fd);

    return 0;
}
/*Hello, World!
*/