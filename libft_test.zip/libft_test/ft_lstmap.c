/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:34:33 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:34:36 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to create a new linked list by applying a given function 'f' to each node in the original list
t_list *ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
    t_list *new_lst;          // A pointer to the new linked list
    t_list *node;             // A pointer to a node in the new list
    void *mapped_content;     // A pointer to the content of the mapped node

    // Check if the input parameters 'lst', 'f', or 'del' are NULL
    if (!lst || !f || !del)
        return (NULL);

    new_lst = NULL;  // Initialize the new list as empty

    // Loop through the original list and map each node's content using the function 'f'
    while (lst)
    {
        mapped_content = f(lst->content);  // Apply 'f' to the content of the current node

        // Create a new node with the mapped content
        node = ft_lstnew(mapped_content);

        // Check if memory allocation for the new node failed
        if (!node)
        {
            del(mapped_content);           // Delete the mapped content using 'del'
            ft_lstclear(&new_lst, del);    // Clear the new list and delete its contents
            return (NULL);                 // Return NULL to indicate failure
        }

        ft_lstadd_back(&new_lst, node);  // Add the new node to the end of the new list
        lst = lst->next;                 // Move to the next node in the original list
    }

    return (new_lst);  // Return the new list containing mapped nodes
}

#include <stdio.h>
#include <stdlib.h>  // Include standard library for memory allocation

// A sample mapping function that appends " Mapped" to a string
void *map_string(void *content)
{
    char *original = (char *)content;
    char *mapped = (char *)malloc(strlen(original) + 8);  // Allocate memory for the mapped content
    strcpy(mapped, original);
    strcat(mapped, " Mapped");
    return (void *)mapped;
}

// A sample deletion function that frees the memory of a string
void free_string(void *content)
{
    free(content);
}

int main()
{
    // Create a linked list with nodes containing strings
    t_list *node1 = ft_lstnew(ft_strdup("Node 1 data"));
    t_list *node2 = ft_lstnew(ft_strdup("Node 2 data"));
    t_list *node3 = ft_lstnew(ft_strdup("Node 3 data"));

    // Initialize a pointer to the head of the list
    t_list *head = node1;

    // Connect the nodes to form a linked list
    node1->next = node2;
    node2->next = node3;

    // Create a new list by mapping the original list using the map_string function
    t_list *new_list = ft_lstmap(head, map_string, free_string);

    // Print the content of the new list
    t_list *current = new_list;
    while (current)
    {
        printf("%s\n", (char *)current->content);
        current = current->next;
    }

    // Free the memory allocated for both the original and new lists
    ft_lstclear(&head, free_string);
    ft_lstclear(&new_list, free_string);

    return 0;
}
