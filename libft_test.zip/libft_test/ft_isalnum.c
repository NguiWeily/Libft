/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:22:45 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:22:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int ft_isalnum(int c) {
    // Check if the character is either alphabetic or a digit
    return (ft_isalpha(c) || ft_isdigit(c));
}

#include <stdio.h>
#include "libft.h"  // Include the necessary header file

int main() {
    char test_char1 = 'A'; // Alphabetic character
    char test_char2 = '7'; // Digit
    char test_char3 = '$'; // Special character

    // Check if the characters are alphanumeric using ft_isalnum
    if (ft_isalnum(test_char1)) {
        printf("%c is alphanumeric.\n", test_char1);
    } else {
        printf("%c is not alphanumeric.\n", test_char1);
    }

    if (ft_isalnum(test_char2)) {
        printf("%c is alphanumeric.\n", test_char2);
    } else {
        printf("%c is not alphanumeric.\n", test_char2);
    }

    if (ft_isalnum(test_char3)) {
        printf("%c is alphanumeric.\n", test_char3);
    } else {
        printf("%c is not alphanumeric.\n", test_char3);
    }

    return 0;
}
/* In this main function:

We declare three character variables (test_char1, test_char2, and test_char3) with different characters for testing.

We use the ft_isalnum function to check if each character is alphanumeric.

For each character, we print a message indicating whether it is alphanumeric or not based on the result of the ft_isalnum function.

The output will indicate whether each character is alphanumeric or not based on the definition provided by the ft_isalnum function.

This test code demonstrates how to use the ft_isalnum function to check if a character is alphanumeric.
*/