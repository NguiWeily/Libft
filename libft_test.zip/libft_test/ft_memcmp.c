/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:35:58 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:36:02 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to compare two memory blocks 's1' and 's2' up to 'n' bytes
int ft_memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *p1;  // Pointer to traverse 's1'
    const unsigned char *p2;  // Pointer to traverse 's2'

    p1 = (const unsigned char *)s1;  // Cast 's1' to an unsigned char pointer
    p2 = (const unsigned char *)s2;  // Cast 's2' to an unsigned char pointer

    // Loop through the memory blocks 's1' and 's2' for 'n' bytes
    while (n-- > 0)
    {
        // Compare the current bytes at 'p1' and 'p2'
        if (*p1 != *p2)
            return (*p1 - *p2);  // Return the difference between the first differing bytes

        p1++;  // Move to the next byte in 's1'
        p2++;  // Move to the next byte in 's2'
    }

    return (0);  // Return 0 if the memory blocks are identical up to 'n' bytes
}

#include <stdio.h>
#include <string.h>

int main()
{
    // Define two memory blocks (byte arrays) to compare
    char block1[] = "Hello, World!";
    char block2[] = "Hello, Planet!";

    // Compare the memory blocks using ft_memcmp
    int result = ft_memcmp(block1, block2, strlen(block1));

    if (result < 0)
    {
        printf("block1 is less than block2\n");
        // Should print "block1 is less than block2"
    }
    else if (result > 0)
    {
        printf("block1 is greater than block2\n");
    }
    else
    {
        printf("block1 is equal to block2\n");
    }

    return 0;
}
/*block1 is less than block2
*/