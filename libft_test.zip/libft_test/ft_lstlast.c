/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstlast.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:33:04 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:33:07 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to find and return the last node in a linked list
t_list *ft_lstlast(t_list *lst)
{
    // Loop through the linked list until the last node is reached
    while (lst && lst->next)
    {
        lst = lst->next;  // Move to the next node in the list
    }

    // Return a pointer to the last node (or NULL if the list is empty)
    return (lst);
}

#include <stdio.h>

int main()
{
    // Create a linked list with nodes containing integers
    t_list *node1 = ft_lstnew(ft_strdup("Node 1 data"));
    t_list *node2 = ft_lstnew(ft_strdup("Node 2 data"));
    t_list *node3 = ft_lstnew(ft_strdup("Node 3 data"));

    // Initialize a pointer to the head of the list
    t_list *head = node1;

    // Connect the nodes to form a linked list
    node1->next = node2;
    node2->next = node3;

    // Find the last node in the list using ft_lstlast
    t_list *last_node = ft_lstlast(head);

    // Print the content of the last node (assuming it's a string)
    if (last_node)
    {
        printf("Last node content: %s\n", (char *)last_node->content);
        // Should print "Last node content: Node 3 data"
    }
    else
    {
        printf("The list is empty.\n");
    }

    return 0;
}
