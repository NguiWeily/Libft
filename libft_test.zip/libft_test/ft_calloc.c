/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:22:13 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:22:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void *ft_calloc(size_t count, size_t size) {
    void *ptr;

    // Allocate memory for 'count' objects of 'size' bytes each
    ptr = malloc(count * size);

    // Check if malloc failed (unable to allocate memory)
    if (!ptr)
        return (NULL);

    // Use ft_bzero to zero out the allocated memory
    ft_bzero(ptr, (count * size));

    return (ptr);
}

#include <stdio.h>
#include <stdlib.h> // For free function

int main() {
    size_t num_elements = 5;
    size_t element_size = sizeof(int);

    // Allocate memory using ft_calloc
    int *array = (int *)ft_calloc(num_elements, element_size);

    if (array == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Print the initialized array
    printf("Initialized Array:\n");
    for (size_t i = 0; i < num_elements; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    // Free the allocated memory
    free(array);

    return 0;
}

/*Initialized Array:
0 0 0 0 0
*/
