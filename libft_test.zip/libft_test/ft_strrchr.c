/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:43:10 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:43:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to locate the last occurrence of character 'c' in string 's'
char *ft_strrchr(const char *s, int c)
{
    int i;  // Index variable for iterating through the string 's'

    // Calculate the length of the string 's' and add 1 to start from the null terminator
    i = (int)ft_strlen(s) + 1;

    // Start from the end of the string and search backwards
    while (i--)
    {
        if (*(s + i) == (char)c)  // Check if the current character matches 'c'
            return ((char *)s + i);  // If a match is found, return a pointer to the matched character
    }

    return (NULL);  // If no match is found, return NULL
}

#include <stdio.h>

int main()
{
    // Input string
    const char input[] = "Hello, World!";
    int character_to_find = 'o';

    // Call ft_strrchr to locate the last occurrence of 'o' in the input string
    char *result = ft_strrchr(input, character_to_find);

    if (result)
    {
        printf("Last Occurrence Found: %s\n", result);
    }
    else
    {
        printf("Character Not Found\n");
    }

    return 0;
}

/*Last Occurrence Found: o, World!
*/