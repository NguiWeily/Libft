/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:41:06 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:41:10 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to calculate the length of a null-terminated string 's'
size_t ft_strlen(const char *s)
{
    size_t len;  // Variable to store the length of the string 's'

    len = 0;  // Initialize the length to 0

    // Loop through the string 's' until a null terminator is encountered
    while (s[len])
        len++;  // Increment the length for each character in 's'

    return (len);  // Return the calculated length of the string 's'
}

#include <stdio.h>

int main()
{
    // Input string
    const char input[] = "Hello, World!";

    // Call ft_strlen to calculate the length of the input string
    size_t length = ft_strlen(input);

    printf("Length of the String: %zu\n", length);

    return 0;
}

/*Length of the String: 13
*/