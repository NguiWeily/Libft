/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:43:34 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:43:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to remove leading and trailing characters from 's1' that match any character in 'set'
char *ft_strtrim(char const *s1, char const *set)
{
    char *trimmed;  // Pointer to the trimmed string
    size_t start;   // Index of the first non-matching character
    size_t end;     // Index of the last non-matching character

    if (!s1 || !set)  // Check if either 's1' or 'set' is NULL
        return (NULL);  // If either is NULL, return NULL

    start = 0;  // Initialize the start index to 0
    end = ft_strlen(s1) - 1;  // Initialize the end index to the last character in 's1'

    // Remove leading characters in 's1' that match any character in 'set'
    while (s1[start] && ft_strchr(set, s1[start]))
        start++;

    if (start == end + 1)  // Check if 'start' reached the end, indicating all characters were removed
        return (ft_strdup(""));  // If so, return an empty string

    // Remove trailing characters in 's1' that match any character in 'set'
    while (ft_strchr(set, s1[end]))
        end--;

    // Create a new string containing the trimmed portion of 's1'
    trimmed = ft_substr(s1, start, end - start + 1);

    if (!trimmed)  // Check if memory allocation failed
        return (NULL);  // If allocation failed, return NULL

    return (trimmed);  // Return the trimmed string
}

#include <stdio.h>

int main()
{
    // Input string and set of characters to trim
    const char input[] = "   Hello, World!   ";
    const char set[] = " ";

    // Call ft_strtrim to trim characters in 'input' using 'set'
    char *result = ft_strtrim(input, set);

    if (result)
    {
        printf("Trimmed String: \"%s\"\n", result);
    }
    else
    {
        printf("Trimming Failed\n");
    }

    return 0;
}

/*Trimmed String: "Hello, World!"
*/