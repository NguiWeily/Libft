/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:44:24 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:44:27 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to convert an uppercase character to lowercase if it is an uppercase letter
int ft_tolower(int c)
{
    if (c >= 'A' && c <= 'Z')  // Check if 'c' is an uppercase letter (ASCII values)
    {
        return (c + 32);  // If 'c' is uppercase, add 32 to its ASCII value to convert to lowercase
    }
    return (c);  // If 'c' is not an uppercase letter, return it unchanged
}

#include <stdio.h>

int main()
{
    // Test characters
    char upperCaseChar = 'A';  // Uppercase 'A'
    char nonUpperCaseChar = 'x';  // A non-uppercase character

    // Call ft_tolower to convert 'upperCaseChar' to lowercase
    int result1 = ft_tolower(upperCaseChar);

    // Call ft_tolower with a non-uppercase character (should remain unchanged)
    int result2 = ft_tolower(nonUpperCaseChar);

    printf("Result 1: %c\n", result1);
    printf("Result 2: %c\n", result2);

    return 0;
}

/*Result 1: a
Result 2: x
*/