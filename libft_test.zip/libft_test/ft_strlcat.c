/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:44:25 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:44:29 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to concatenate two strings with size limitation and ensure null-termination
size_t ft_strlcat(char *dst, const char *src, size_t dstsize)
{
    size_t dst_len;  // Length of the destination string 'dst'
    size_t src_len;  // Length of the source string 'src'

    src_len = ft_strlen(src);  // Calculate the length of the source string 'src'

    if (dstsize == 0)  // Check if the destination size is 0 (no space for concatenation)
        return (src_len);  // Return the length of 'src' as there is no room for concatenation

    dst_len = ft_strlen(dst);  // Calculate the length of the destination string 'dst'

    if (dst_len >= dstsize)  // Check if the destination string is already at its limit
        return (src_len + dstsize);  // Return the total length of 'src' and 'dstsize'

    dst += dst_len;  // Move the destination pointer to the end of 'dst'
    dstsize -= dst_len;  // Adjust 'dstsize' based on the length of 'dst'

    // Copy characters from 'src' to 'dst' while there is space available and 'src' is not null-terminated
    while (*src && --dstsize)
        *dst++ = *src++;

    *dst = '\0';  // Ensure that the destination string is null-terminated

    // Return the total length of the concatenated string (original 'dst_len' + 'src_len')
    return (dst_len + src_len);
}

#include <stdio.h>

int main()
{
    // Destination buffer
    char dst[15] = "Hello";

    // Source string to concatenate
    const char src[] = ", World!";

    // Call ft_strlcat to concatenate 'src' to 'dst' with size limitation
    size_t result_len = ft_strlcat(dst, src, sizeof(dst));

    printf("Concatenated String: %s\n", dst);
    printf("Result Length: %zu\n", result_len);

    return 0;
}

/*Concatenated String: Hello, World!
Result Length: 13
*/