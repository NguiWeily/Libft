/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:40:46 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:40:49 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to copy a string 'src' to a destination 'dst' with a size limitation
size_t ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
    size_t src_len;  // Length of the source string 'src'
    size_t i;        // Index variable for iterating through 'src'

    src_len = ft_strlen(src);  // Calculate the length of the source string 'src'
    i = 0;                     // Initialize the index to 0

    if (dstsize > 0)  // Check if the destination size is greater than 0
    {
        while (src[i] && i < dstsize - 1)
        {
            dst[i] = src[i];  // Copy characters from 'src' to 'dst'
            i++;
        }
        dst[i] = '\0';  // Ensure that the destination string is null-terminated
    }

    return (src_len);  // Return the length of the source string 'src'
}

#include <stdio.h>

int main()
{
    // Destination buffer
    char dst[10];

    // Source string to copy
    const char src[] = "Hello, World!";

    // Call ft_strlcpy to copy 'src' to 'dst' with size limitation
    size_t result_len = ft_strlcpy(dst, src, sizeof(dst));

    printf("Copied String: %s\n", dst);
    printf("Result Length: %zu\n", result_len);

    return 0;
}

/*Copied String: Hello, Wo
Result Length: 13
*/