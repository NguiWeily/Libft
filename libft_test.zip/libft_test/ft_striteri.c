/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:42:35 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:42:38 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to apply a given function 'f' to each character in a string 's' with its index
void ft_striteri(char *s, void (*f)(unsigned int, char *))
{
    int i;  // Index variable to track the position of characters in 's'

    if (!s || !f)  // Check if 's' or 'f' is NULL
        return ;    // If either 's' or 'f' is NULL, return without doing anything

    i = 0;  // Initialize the index to 0

    // Loop through the string 's' until the null terminator is encountered
    while (s[i])
    {
        f(i, &s[i]);  // Call the function 'f' with the current index 'i' and character '&s[i]'
        i++;          // Increment the index to move to the next character in 's'
    }
}

#include <stdio.h>

// Function to print the character and its index
void print_char_index(unsigned int index, char *c)
{
    printf("Character at index %u: %c\n", index, *c);
}

int main()
{
    // Input string
    char input[] = "Hello";

    // Call ft_striteri to apply the print_char_index function to each character in the string
    ft_striteri(input, print_char_index);

    return 0;
}
 /*Character at index 0: H
Character at index 1: e
Character at index 2: l
Character at index 3: l
Character at index 4: o
*/