/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:35:38 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:35:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to search for the first occurrence of a byte 'c' in a memory block 's' of 'n' bytes
void *ft_memchr(const void *s, int c, size_t n)
{
    const unsigned char *ptr;  // Pointer to traverse the memory block 's'

    ptr = (unsigned char *)s;  // Cast 's' to an unsigned char pointer

    // Loop through the memory block 's' for 'n' bytes
    while (n--)
    {
        // Check if the current byte at 'ptr' matches the target byte 'c'
        if (*ptr == (unsigned char)c)
            return ((void *)ptr);  // Return a pointer to the matching byte

        ptr++;  // Move to the next byte in the memory block
    }

    return (NULL);  // Return NULL if the target byte is not found in the memory block
}

#include <stdio.h>
#include <string.h>

int main()
{
    // Define a test string and a target character
    const char *test_string = "Hello, World!";
    char target_char = 'W';

    // Search for the target character in the test string using ft_memchr
    void *result = ft_memchr(test_string, target_char, strlen(test_string));

    if (result)
    {
        printf("Target character found at position: %ld\n", (char *)result - test_string);
        // Should print "Target character found at position: 7"
    }
    else
    {
        printf("Target character not found in the string.\n");
    }

    return 0;
}
