/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:37:10 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:37:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to copy 'len' bytes from source 'src' to destination 'dst'
void *ft_memmove(void *dst, const void *src, size_t len)
{
    unsigned char *d;  // Pointer to traverse the destination memory block 'dst'
    unsigned char *s;  // Pointer to traverse the source memory block 'src'

    // Check if both 'dst' and 'src' are NULL (edge case)
    if (!dst && !src)
        return (NULL);

    d = (unsigned char *)dst;  // Cast 'dst' to an unsigned char pointer
    s = (unsigned char *)src;  // Cast 'src' to an unsigned char pointer

    // Check if 'src' overlaps with 'dst' and choose the appropriate copy direction
    if (s < d && d < s + len)
    {
        // Copy from the end of 'src' to the end of 'dst' (backwards)
        while (len--)
            d[len] = s[len];
    }
    else
    {
        // Copy from the beginning of 'src' to 'dst' (forwards)
        while (len--)
            *(d++) = *(s++);
    }

    return (dst);  // Return a pointer to the destination memory block 'dst'
}

#include <stdio.h>
#include <string.h>

int main()
{
    // Define source and destination memory blocks
    char src[] = "Source String";
    char dst[15];  // Destination block with sufficient space

    // Copy 'src' to 'dst' using ft_memmove
    ft_memmove(dst, src, strlen(src) + 1);

    // Print the copied string in 'dst'
    printf("Copied String: %s\n", dst);
    // Should print "Copied String: Source String"

    return 0;
}
/*Copied String: Source String
*/