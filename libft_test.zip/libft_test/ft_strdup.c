/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:42:09 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:42:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to duplicate a string 's1' and return a new dynamically allocated string
char *ft_strdup(const char *s1)
{
    size_t len;  // Variable to store the length of the original string 's1'
    char *dup;   // Pointer to the duplicated string

    len = ft_strlen(s1) + 1;  // Calculate the length of 's1' including the null terminator

    // Allocate memory for the duplicated string with a size of 'len' bytes
    dup = (char *)malloc(sizeof(char) * (len));

    if (!dup)  // Check if memory allocation failed
        return (NULL);  // If allocation failed, return NULL

    // Copy the content of the original string 's1' to the newly allocated memory
    ft_memcpy(dup, s1, len);

    return (dup);  // Return a pointer to the duplicated string
}

#include <stdio.h>
#include <stdlib.h>  // Include the standard library for memory allocation functions

int main()
{
    // Input string to be duplicated
    const char input[] = "Hello, World!";
    
    // Call ft_strdup to duplicate the input string
    char *duplicate = ft_strdup(input);

    if (duplicate)
    {
        printf("Original String: %s\n", input);
        printf("Duplicated String: %s\n", duplicate);

        // Free the memory allocated for the duplicated string
        free(duplicate);
    }
    else
    {
        printf("Memory allocation failed\n");
    }

    return 0;
}

/*Original String: Hello, World!
Duplicated String: Hello, World!
*/