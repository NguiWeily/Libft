/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:38:01 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:38:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to write a single character 'c' to a specified file descriptor 'fd'
void ft_putchar_fd(char c, int fd)
{
    write(fd, &c, 1);  // Use the 'write' system call to write 'c' to 'fd' with a length of 1 byte
}

#include <stdio.h>
#include <unistd.h>  // Include the standard library for the 'write' function

int main()
{
    // File descriptor for standard output (stdout)
    int fd = 1;

    // Call ft_putchar_fd to write a character to stdout
    ft_putchar_fd('A', fd);

    return 0;
}
