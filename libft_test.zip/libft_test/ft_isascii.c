/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:26:37 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:26:43 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Define a function named ft_isascii that takes an integer 'c' as a parameter
int	ft_isascii(int c)
{
	// Check if 'c' is within the ASCII range (0 to 127)
	// If 'c' is greater than or equal to 0 and less than or equal to 127,
	// the function returns 1 (true), indicating that 'c' is an ASCII character.
	// Otherwise, it returns 0 (false).
	return (c >= 0 && c <= 127);
}

// Main test code
int main()
{
	// Test the ft_isascii function with various inputs and print the results
	int test1 = ft_isascii('A'); // 'A' is an ASCII character, so test1 should be 1 (true)
	int test2 = ft_isascii(128); // 128 is not within the ASCII range, so test2 should be 0 (false)
	int test3 = ft_isascii('$'); // '$' is an ASCII character, so test3 should be 1 (true)

	// Print the results of the tests
	printf("Test 1: Is 'A' an ASCII character? %d\n", test1); // Should print "Test 1: Is 'A' an ASCII character? 1"
	printf("Test 2: Is 128 an ASCII character? %d\n", test2); // Should print "Test 2: Is 128 an ASCII character? 0"
	printf("Test 3: Is '$' an ASCII character? %d\n", test3); // Should print "Test 3: Is '$' an ASCII character? 1"

	return 0; // Return 0 to indicate successful execution of the program
}
