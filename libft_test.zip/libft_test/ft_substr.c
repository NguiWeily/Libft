/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:43:56 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:44:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to create a new substring of 'len' characters starting from 'start' in string 's'
char *ft_substr(char const *s, unsigned int start, size_t len)
{
    char *substr;   // Pointer to the created substring
    size_t slen;    // Length of the input string 's'

    if (!s)  // Check if 's' is NULL
        return (NULL);  // If 's' is NULL, return NULL

    slen = ft_strlen(s);  // Calculate the length of the input string 's'

    if (start >= slen)  // Check if 'start' is greater than or equal to the length of 's'
        return (ft_strdup(""));  // If so, return an empty string

    if (len > slen - start)  // Check if 'len' exceeds the remaining characters from 'start' to the end of 's'
        len = slen - start;  // If so, limit 'len' to the remaining characters

    // Allocate memory for the substring with a size of 'len + 1' (for the null terminator)
    substr = (char *)malloc(sizeof(char) * (len + 1));

    if (!substr)  // Check if memory allocation failed
        return (NULL);  // If allocation failed, return NULL

    // Copy the substring from 's' starting from 'start' with 'len' characters
    ft_memcpy(substr, s + start, len);

    substr[len] = '\0';  // Ensure that the substring is null-terminated

    return (substr);  // Return the created substring
}

#include <stdio.h>

int main()
{
    // Input string
    const char input[] = "Hello, World!";
    unsigned int start = 7;  // Start from character 'W'
    size_t length = 5;       // Create a substring of 5 characters

    // Call ft_substr to create a substring of 'input' starting from 'start' with length 'length'
    char *result = ft_substr(input, start, length);

    if (result)
    {
        printf("Substring: \"%s\"\n", result);
    }
    else
    {
        printf("Substring Creation Failed\n");
    }

    return 0;
}

/*Substring: "World"
*/