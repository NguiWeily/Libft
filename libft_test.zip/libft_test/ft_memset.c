/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:37:34 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:37:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to set 'len' bytes in memory block 'b' to the value 'c'
void *ft_memset(void *b, int c, size_t len)
{
    unsigned char *ptr;  // Pointer to traverse the memory block 'b'

    ptr = (unsigned char *)b;  // Cast 'b' to an unsigned char pointer

    // Loop through 'len' bytes and set each byte to the value 'c'
    while (len--)
        *ptr++ = (unsigned char)c;  // Set the current byte to 'c' and advance the pointer

    return (b);  // Return a pointer to the updated memory block 'b'
}

#include <stdio.h>

int main()
{
    // Define a memory block and set it to zeros using ft_memset
    char buffer[10];
    ft_memset(buffer, 0, sizeof(buffer));

    // Print the contents of the buffer
    printf("Buffer Contents: ");
    for (int i = 0; i < sizeof(buffer); i++)
    {
        printf("%d ", buffer[i]);
    }
    printf("\n");

    return 0;
}
