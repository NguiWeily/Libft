/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:28:28 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:29:25 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to add a new element to the end of a linked list
void ft_lstadd_back(t_list **lst, t_list *new)
{
    // Check if the pointer to the linked list is NULL (empty list)
    if (!*lst)
    {
        // If the list is empty, make the new element the head of the list
        *lst = new;
    }
    else
    {
        // If the list is not empty, find the last element of the list
        // using the ft_lstlast function (assuming it's defined elsewhere)
        ft_lstlast(*lst)->next = new;
        // Connect the last element's 'next' pointer to the new element
    }
}

#int main()
{
    // Create a few linked list nodes
    t_list *node1 = ft_lstnew("Node 1 data");
    t_list *node2 = ft_lstnew("Node 2 data");
    t_list *node3 = ft_lstnew("Node 3 data");

    // Initialize a pointer to the head of the list
    t_list *head = NULL;

    // Add nodes to the end of the list
    ft_lstadd_back(&head, node1);
    ft_lstadd_back(&head, node2);
    ft_lstadd_back(&head, node3);

    // Print the contents of the linked list
    t_list *current = head;
    while (current)
    {
        printf("%s\n", (char *)current->content);
        current = current->next;
    }

    // Free the memory allocated for the nodes (assuming ft_lstclear is defined elsewhere)
    ft_lstclear(&head, free);

    return 0;
}

/*Node 1 data
Node 2 data
Node 3 data
*/