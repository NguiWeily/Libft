/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:42:59 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:43:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to concatenate two strings 's1' and 's2' and return a new dynamically allocated string
char *ft_strjoin(char const *s1, char const *s2)
{
    char *result;        // Pointer to the concatenated string
    size_t len1, len2;   // Variables to store the lengths of 's1' and 's2'

    if (!s1 || !s2)      // Check if either 's1' or 's2' is NULL
        return (NULL);   // If either is NULL, return NULL

    len1 = ft_strlen(s1);  // Calculate the length of 's1'
    len2 = ft_strlen(s2);  // Calculate the length of 's2'

    // Allocate memory for the concatenated string with a size of 'len1 + len2 + 1' (for the null terminator)
    result = (char *)malloc(sizeof(char) * (len1 + len2 + 1));

    if (!result)          // Check if memory allocation failed
        return (NULL);    // If allocation failed, return NULL

    // Copy the content of 's1' to the beginning of 'result'
    ft_memcpy(result, s1, len1);

    // Copy the content of 's2' to the end of 'result' and add a null terminator
    ft_memcpy(result + len1, s2, len2 + 1);

    return (result);      // Return a pointer to the concatenated string
}

#include <stdio.h>
#include <stdlib.h>  // Include the standard library for memory allocation functions

int main()
{
    // Input strings to be concatenated
    const char s1[] = "Hello, ";
    const char s2[] = "World!";

    // Call ft_strjoin to concatenate the input strings
    char *result = ft_strjoin(s1, s2);

    if (result)
    {
        printf("Concatenated String: %s\n", result);

        // Free the memory allocated for the concatenated string
        free(result);
    }
    else
    {
        printf("Memory allocation failed\n");
    }

    return 0;
}

/*Concatenated String: Hello, World!
*/