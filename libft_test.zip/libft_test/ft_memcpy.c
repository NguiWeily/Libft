/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:36:41 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:36:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to copy 'n' bytes from source 'src' to destination 'dst'
void *ft_memcpy(void *dst, const void *src, size_t n)
{
    unsigned char *d;  // Pointer to traverse the destination memory block 'dst'
    unsigned char *s;  // Pointer to traverse the source memory block 'src'

    // Check if both 'dst' and 'src' are NULL (edge case)
    if (!dst && !src)
        return (NULL);

    d = (unsigned char *)dst;  // Cast 'dst' to an unsigned char pointer
    s = (unsigned char *)src;  // Cast 'src' to an unsigned char pointer

    // Loop through 'n' bytes and copy from 'src' to 'dst'
    while (n--)
        *d++ = *s++;  // Copy the byte from 'src' to 'dst' and advance the pointers

    return (dst);  // Return a pointer to the destination memory block 'dst'
}

#include <stdio.h>
#include <string.h>

int main()
{
    // Define source and destination memory blocks
    char src[] = "Source String";
    char dst[15];  // Destination block with sufficient space

    // Copy 'src' to 'dst' using ft_memcpy
    ft_memcpy(dst, src, strlen(src) + 1);

    // Print the copied string in 'dst'
    printf("Copied String: %s\n", dst);
    // Should print "Copied String: Source String"

    return 0;
}
/*Copied String: Source String
*/