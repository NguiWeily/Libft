/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:42:37 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:42:40 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to locate a substring 'needle' in a string 'haystack' within the first 'len' characters
char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
    size_t needle_len;    // Length of the substring 'needle'
    size_t haystack_len;  // Length of the string 'haystack'

    if (!*needle)  // Check if 'needle' is an empty string
        return ((char *)haystack);  // If 'needle' is empty, return 'haystack'

    if (len == 0)  // Check if 'len' is 0
        return (NULL);  // If 'len' is 0, return NULL (no search within the string)

    needle_len = ft_strlen(needle);    // Calculate the length of 'needle'
    haystack_len = ft_strlen(haystack);  // Calculate the length of 'haystack'

    if (len > haystack_len)  // Check if 'len' is greater than the length of 'haystack'
        len = haystack_len;  // If so, limit 'len' to the length of 'haystack'

    while (len >= needle_len)  // Loop while there are enough characters in 'len' to compare
    {
        if (ft_strncmp(haystack, needle, needle_len) == 0)  // Compare 'haystack' with 'needle' of 'needle_len' characters
            return ((char *)haystack);  // If a match is found, return the current position in 'haystack'

        haystack++;  // Move to the next character in 'haystack'
        len--;       // Decrease 'len' to indicate the remaining characters
    }

    return (NULL);  // If no match is found, return NULL
}

#include <stdio.h>

int main()
{
    // Input strings
    const char haystack[] = "Hello, World!";
    const char needle[] = "World";
    size_t len = 13;  // Search within the first 13 characters

    // Call ft_strnstr to find 'needle' in 'haystack' within the first 'len' characters
    char *result = ft_strnstr(haystack, needle, len);

    if (result)
    {
        printf("Substring Found: %s\n", result);
    }
    else
    {
        printf("Substring Not Found\n");
    }

    return 0;
}

/*Substring Found: World!
*/