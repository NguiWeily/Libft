/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:28:00 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:28:05 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Helper function to calculate the length of an integer
static int int_len(int n)
{
	int len;

	len = 0;

	// If 'n' is 0, it has one digit, so return 1
	if (n == 0)
		return (1);

	// If 'n' is negative, increment the length by 1
	if (n < 0)
		len++;

	// Count the number of digits in 'n' by dividing it by 10 repeatedly
	while (n)
	{
		n /= 10;
		len++;
	}

	return (len);
}

// Function to convert an integer to a string (itoa)
char *ft_itoa(int n)
{
	int ncpy;
	int i;
	char *str;

	// Special case for the minimum integer value
	if (n == -2147483648)
		return (ft_strdup("-2147483648"));

	// Create a copy of 'n' for processing
	ncpy = n;

	// If 'n' is negative, make it positive for further processing
	if (n < 0)
		ncpy = -n;

	// Calculate the length of the resulting string
	i = int_len(n);

	// Allocate memory for the string, including space for the null terminator
	str = (char *)malloc(sizeof(char) * (i + 1));

	// Check if memory allocation was successful
	if (!str)
		return (NULL);

	// Add the null terminator at the end of the string
	str[i] = '\0';
	i--;

	// If the original 'n' was 0, set the first character of the string to '0'
	if (ncpy == 0)
		str[i] = '0';

	// Convert 'n' to a string by extracting digits
	while (ncpy > 0)
	{
		// Extract the last digit of 'n' and convert it to a character
		str[i--] = (ncpy % 10) + '0';
		ncpy /= 10;
	}

	// If the original 'n' was negative, add a '-' sign to the string
	if (n < 0)
		str[i] = '-';

	// Return the resulting string
	return (str);
}

int main()
{
	int num1 = 12345;
	int num2 = -6789;
	int num3 = 0;

	char *str1 = ft_itoa(num1);
	char *str2 = ft_itoa(num2);
	char *str3 = ft_itoa(num3);

	printf("Number 1: %s\n", str1); // Should print "Number 1: 12345"
	printf("Number 2: %s\n", str2); // Should print "Number 2: -6789"
	printf("Number 3: %s\n", str3); // Should print "Number 3: 0"

	// Remember to free the allocated memory for the strings
	free(str1);
	free(str2);
	free(str3);

	return 0;
}
