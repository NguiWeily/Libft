/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:31:29 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:31:33 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to clear (delete) a linked list and its content using a provided deletion function
void ft_lstclear(t_list **lst, void (*del)(void *))
{
    t_list *buffer;  // Temporary variable to hold the next node to be deleted

    // Check if any of the required parameters is NULL: lst, *lst, or del
    if (!lst || !*lst || !del)
        return;

    // Loop through the linked list and delete each node
    while (*lst)
    {
        buffer = (*lst)->next;  // Store a reference to the next node
        ft_lstdelone(*lst, del);  // Delete the current node and its content using the provided deletion function
        *lst = buffer;  // Move the pointer to the next node
    }
}

// A sample deletion function that frees the memory of a string
void free_string(void *content)
{
    free(content);
}

int main()
{
    // Create a few linked list nodes with string content
    t_list *node1 = ft_lstnew(ft_strdup("Node 1 data"));
    t_list *node2 = ft_lstnew(ft_strdup("Node 2 data"));
    t_list *node3 = ft_lstnew(ft_strdup("Node 3 data"));

    // Initialize a pointer to the head of the list
    t_list *head = node1;

    // Connect the nodes to form a linked list
    node1->next = node2;
    node2->next = node3;

    // Clear (delete) the linked list and its content using the ft_lstclear function
    ft_lstclear(&head, free_string);

    // Verify that the list is now empty (head is NULL)
    if (head == NULL)
    {
        printf("The list is empty.\n"); // Should print "The list is empty."
    }

    return 0;
}
/*The list is empty.
*/