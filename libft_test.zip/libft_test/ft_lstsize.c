/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:35:18 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:35:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to calculate the number of nodes in a linked list
int ft_lstsize(t_list *lst)
{
    int size;  // Variable to store the size of the list

    size = 0;  // Initialize the size to 0

    // Loop through the linked list while it's not NULL
    while (lst)
    {
        size++;         // Increment the size for each node
        lst = lst->next;  // Move to the next node in the list
    }

    return (size);  // Return the total number of nodes in the list
}

#include <stdio.h>

int main()
{
    // Create a linked list with nodes containing integers
    t_list *node1 = ft_lstnew(ft_strdup("Node 1 data"));
    t_list *node2 = ft_lstnew(ft_strdup("Node 2 data"));
    t_list *node3 = ft_lstnew(ft_strdup("Node 3 data"));

    // Initialize a pointer to the head of the list
    t_list *head = node1;

    // Connect the nodes to form a linked list
    node1->next = node2;
    node2->next = node3;

    // Calculate the size of the linked list using ft_lstsize
    int list_size = ft_lstsize(head);

    // Print the size of the list
    printf("Size of the linked list: %d\n", list_size);
    // Should print "Size of the linked list: 3"

    return 0;
}
/*Size of the linked list: 3
*/