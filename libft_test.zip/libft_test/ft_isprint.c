/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:27:29 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:27:34 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Define a function named ft_isprint that takes an integer 'c' as a parameter
int ft_isprint(int c)
{
    // Check if 'c' is a printable character (ASCII values between 32 and 126, inclusive)
    // If 'c' is greater than or equal to 32 (the ASCII value of the space character) and less than or equal to 126 (the ASCII value of '~'),
    // the function returns 1 (true), indicating that 'c' is a printable character.
    // Otherwise, it returns 0 (false).
    return (c >= 32 && c <= 126);
}

// Main test code
int main()
{
    // Test the ft_isprint function with various inputs and print the results
    int test1 = ft_isprint('A');   // 'A' is a printable character, so test1 should be 1 (true)
    int test2 = ft_isprint('\t');  // '\t' (tab) is not a printable character, so test2 should be 0 (false)
    int test3 = ft_isprint('\n');  // '\n' (newline) is not a printable character, so test3 should be 0 (false)
    int test4 = ft_isprint(32);    // 32 is the ASCII value of the space character, so test4 should be 1 (true)
    int test5 = ft_isprint(127);   // 127 is the highest printable ASCII character ('~'), so test5 should be 1 (true)
    int test6 = ft_isprint(128);   // 128 is outside the printable ASCII range, so test6 should be 0 (false)

    // Print the results of the tests
    printf("Test 1: Is 'A' a printable character? %d\n", test1);   // Should print "Test 1: Is 'A' a printable character? 1"
    printf("Test 2: Is '\t' a printable character? %d\n", test2);  // Should print "Test 2: Is '\t' a printable character? 0"
    printf("Test 3: Is '\n' a printable character? %d\n", test3);  // Should print "Test 3: Is '\n' a printable character? 0"
    printf("Test 4: Is 32 a printable character? %d\n", test4);    // Should print "Test 4: Is 32 a printable character? 1"
    printf("Test 5: Is 127 a printable character? %d\n", test5);   // Should print "Test 5: Is 127 a printable character? 1"
    printf("Test 6: Is 128 a printable character? %d\n", test6);   // Should print "Test 6: Is 128 a printable character? 0"

    return 0; // Return 0 to indicate successful execution of the program
}
