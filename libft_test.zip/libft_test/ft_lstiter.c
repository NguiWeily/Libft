/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstiter.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:32:31 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:32:35 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to apply a given function 'f' to each node in a linked list
void ft_lstiter(t_list *lst, void (*f)(void *))
{
    // Check if the function 'f' is NULL
    if (!f)
        return;

    // Loop through the linked list and apply 'f' to each node's content
    while (lst)
    {
        f(lst->content);  // Apply the function 'f' to the content of the current node
        lst = lst->next;  // Move to the next node in the list
    }
}

#include <stdio.h>
#include <stdlib.h>  // Include standard library for memory allocation

// Define a sample function to print the content of a node
void print_node_content(void *content)
{
    printf("%s\n", (char *)content);  // Assume the content is a string
}

int main()
{
    // Create a few linked list nodes with string content
    t_list *node1 = ft_lstnew("Node 1 data");
    t_list *node2 = ft_lstnew("Node 2 data");
    t_list *node3 = ft_lstnew("Node 3 data");

    // Initialize a pointer to the head of the list
    t_list *head = node1;

    // Connect the nodes to form a linked list
    node1->next = node2;
    node2->next = node3;

    // Apply the print_node_content function to each node in the list
    ft_lstiter(head, print_node_content);

    return 0;
}

/*Node 1 data
Node 2 data
Node 3 data
*/