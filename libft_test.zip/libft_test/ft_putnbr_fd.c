/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:39:26 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:39:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to write an integer 'n' to a specified file descriptor 'fd'
void ft_putnbr_fd(int n, int fd)
{
    // Handle the special case where 'n' is the minimum possible integer value
    if (n == -2147483648)
    {
        ft_putnbr_fd(n / 10, fd);   // Recursively print the integer without the last digit
        ft_putstr_fd("8", fd);      // Print the last digit '8' as a string
    }
    // Handle the case where 'n' is negative
    else if (n < 0)
    {
        ft_putchar_fd('-', fd);     // Write a minus sign '-' to indicate a negative number
        ft_putnbr_fd(-n, fd);       // Recursively print the positive value of 'n'
    }
    else  // Handle the case where 'n' is non-negative
    {
        if (n > 9)
            ft_putnbr_fd(n / 10, fd);  // Recursively print the integer without the last digit
        ft_putchar_fd(n % 10 + '0', fd);  // Print the last digit as a character
    }
}

#include <stdio.h>
#include <unistd.h>  // Include the standard library for the 'write' function

int main()
{
    // File descriptor for standard output (stdout)
    int fd = 1;

    // Call ft_putnbr_fd to write an integer to stdout
    ft_putnbr_fd(12345, fd);

    return 0;
}
/*12345
*/