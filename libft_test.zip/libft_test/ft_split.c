/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:41:09 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:41:12 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to calculate the length of a word in a string 's' delimited by character 'c'
static int ft_wordlen(char const *s, char c)
{
    int len;  // Variable to store the length of the word

    len = 0;  // Initialize the length to 0

    // Loop through 's' until a word delimiter 'c' or the end of the string is encountered
    while (*s && *s != c)
    {
        len++;  // Increment the length for each character in the word
        s++;    // Move to the next character in 's'
    }

    return (len);  // Return the length of the word
}

// Function to count the number of words in a string 's' delimited by character 'c'
static int ft_countwords(char const *s, char c)
{
    int count;  // Variable to store the word count

    count = 0;  // Initialize the count to 0

    // Loop through 's' until the end of the string is encountered
    while (*s)
    {
        if (*s != c)  // Check if the current character is not 'c' (part of a word)
        {
            count++;  // Increment the word count
            s += ft_wordlen(s, c);  // Move to the next word
        }
        else
            s++;  // Move to the next character in 's'
    }

    return (count);  // Return the total word count
}

// Function to free memory allocated for an array of strings 'strs'
static void *free_strs(char **strs)
{
    int i;

    i = 0;

    // Loop through 'strs' and free each string
    while (strs[i])
        free(strs[i++]);

    free(strs);  // Free the memory for the array of strings
    return (NULL);
}

// Function to split a string 's' into an array of strings using character 'c' as a delimiter
char **ft_split(char const *s, char c)
{
    char **strs;  // Pointer to an array of strings
    int i;        // Index variable for array 'strs'
    int count;    // Number of words in 's'

    if (!s)  // Check if the input string 's' is NULL
        return (NULL);

    count = ft_countwords(s, c);  // Count the number of words in 's'

    // Allocate memory for an array of strings with 'count + 1' elements (plus NULL termination)
    strs = (char **)malloc(sizeof(char *) * (count + 1));

    if (!strs)  // Check if memory allocation failed
        return (NULL);

    strs[count] = NULL;  // Set the last element to NULL for proper termination

    i = 0;

    // Loop through 's' to split it into words
    while (*s)
    {
        if (*s != c)  // Check if the current character is not 'c' (part of a word)
        {
            // Create a substring from 's' and add it to 'strs'
            strs[i] = ft_substr(s, 0, ft_wordlen(s, c));

            if (!strs[i++])  // Check if memory allocation failed for a substring
                return (free_strs(strs));

            s += ft_wordlen(s, c);  // Move to the next word
        }
        else
            s++;  // Move to the next character in 's'
    }

    return (strs);  // Return the array of strings
}

#include <stdio.h>
#include <stdlib.h>  // Include the standard library for memory allocation functions

int main()
{
    // Input string to split
    char input[] = "This is a test string";

    // Character delimiter for splitting
    char delimiter = ' ';

    // Call ft_split to split the input string into an array of strings
    char **result = ft_split(input, delimiter);

    if (result)
    {
        // Print the split words
        for (int i = 0; result[i]; i++)
        {
            printf("Word %d: %s\n", i, result[i]);
        }

        // Free the memory allocated for the array of strings
        free(result);
    }

    return 0;
}

/*Word 0: This
Word 1: is
Word 2: a
Word 3: test
Word 4: string
*/