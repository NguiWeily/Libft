/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 17:42:06 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 17:42:10 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to compare two strings 's1' and 's2' up to 'n' characters
int ft_strncmp(const char *s1, const char *s2, size_t n)
{
    size_t i;  // Index variable for iterating through the strings

    i = 0;     // Initialize the index to 0

    if (n == 0)  // Check if the comparison length is 0
        return (0);  // If 'n' is 0, the strings are considered equal

    while (s1[i] != '\0' && s1[i] == s2[i] && i < n - 1)
    {
        i++;  // Increment the index while characters match and 'n' is not reached
    }

    // Return the difference between the first differing characters as integers
    return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}

#include <stdio.h>

int main()
{
    // Input strings to be compared
    const char str1[] = "Hello, World!";
    const char str2[] = "Hello, World!";
    const char str3[] = "Hello, Coder!";
    size_t n = 13;  // Comparison length

    // Call ft_strncmp to compare the input strings up to 'n' characters
    int result1 = ft_strncmp(str1, str2, n);  // Should be 0 (equal)
    int result2 = ft_strncmp(str1, str3, n);  // Should be a negative value

    printf("Result 1: %d\n", result1);
    printf("Result 2: %d\n", result2);

    return 0;
}

/*Result 1: 0
Result 2: 2
*/