/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_front.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:29:54 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:30:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to add a new element to the front of a linked list
void ft_lstadd_front(t_list **lst, t_list *new)
{
    // Set the 'next' pointer of the new element to the current head of the list
    new->next = *lst;

    // Update the head of the list to be the new element
    *lst = new;
}

int main()
{
    // Create a few linked list nodes
    t_list *node1 = ft_lstnew("Node 1 data");
    t_list *node2 = ft_lstnew("Node 2 data");
    t_list *node3 = ft_lstnew("Node 3 data");

    // Initialize a pointer to the head of the list
    t_list *head = NULL;

    // Add nodes to the front of the list
    ft_lstadd_front(&head, node3);
    ft_lstadd_front(&head, node2);
    ft_lstadd_front(&head, node1);

    // Print the contents of the linked list
    t_list *current = head;
    while (current)
    {
        printf("%s\n", (char *)current->content);
        current = current->next;
    }

    // Free the memory allocated for the nodes (assuming ft_lstclear is defined elsewhere)
    ft_lstclear(&head, free);

    return 0;
}
/*Node 1 data
Node 2 data
Node 3 data
*/