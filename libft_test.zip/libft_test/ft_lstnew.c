/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:34:13 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:34:17 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Function to create a new linked list node with the given content
t_list *ft_lstnew(void *content)
{
    t_list *head;  // Pointer to the new linked list node

    // Allocate memory for the new node
    head = (t_list *)malloc(sizeof(t_list));

    // Check if memory allocation failed
    if (!head)
        return (NULL);  // Return NULL to indicate failure

    head->content = content;  // Set the content of the new node
    head->next = NULL;        // Initialize the 'next' pointer to NULL (end of the list)

    return (head);  // Return a pointer to the new node
}

#include <stdio.h>
#include <stdlib.h>  // Include standard library for memory allocation

int main()
{
    // Create a new linked list node with a string content
    t_list *node = ft_lstnew(ft_strdup("Node 1 data"));

    // Check if memory allocation for the node succeeded
    if (node)
    {
        printf("Node content: %s\n", (char *)node->content);
        // Should print "Node content: Node 1 data"
    }
    else
    {
        printf("Memory allocation failed.\n");
    }

    // Free the memory allocated for the node
    free(node->content);  // Assuming ft_strdup was used for content allocation
    free(node);

    return 0;
}
/*Node content: Node 1 data
*/