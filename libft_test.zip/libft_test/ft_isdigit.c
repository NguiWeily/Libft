/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:27:04 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:27:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"  // Include the header file "libft.h"

// Define a function named ft_isdigit that takes an integer 'c' as a parameter
int ft_isdigit(int c)
{
    // Check if 'c' is a digit character (0 to 9)
    // If 'c' is greater than or equal to '0' (ASCII value of '0') and less than or equal to '9' (ASCII value of '9'),
    // the function returns 1 (true), indicating that 'c' is a digit character.
    // Otherwise, it returns 0 (false).
    return (c >= '0' && c <= '9');
}

// Main test code
int main()
{
    // Test the ft_isdigit function with various inputs and print the results
    int test1 = ft_isdigit('5');   // '5' is a digit character, so test1 should be 1 (true)
    int test2 = ft_isdigit('A');   // 'A' is not a digit character, so test2 should be 0 (false)
    int test3 = ft_isdigit('$');   // '$' is not a digit character, so test3 should be 0 (false)
    int test4 = ft_isdigit(49);    // 49 is the ASCII value of '1', so test4 should be 1 (true)
    int test5 = ft_isdigit(58);    // 58 is the ASCII value of ':', which is not a digit character, so test5 should be 0 (false)

    // Print the results of the tests
    printf("Test 1: Is '5' a digit character? %d\n", test1);   // Should print "Test 1: Is '5' a digit character? 1"
    printf("Test 2: Is 'A' a digit character? %d\n", test2);   // Should print "Test 2: Is 'A' a digit character? 0"
    printf("Test 3: Is '$' a digit character? %d\n", test3);   // Should print "Test 3: Is '$' a digit character? 0"
    printf("Test 4: Is 49 a digit character? %d\n", test4);    // Should print "Test 4: Is 49 a digit character? 1"
    printf("Test 5: Is 58 a digit character? %d\n", test5);    // Should print "Test 5: Is 58 a digit character? 0"

    return 0; // Return 0 to indicate successful execution of the program
}
