/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/06 16:21:38 by wngui             #+#    #+#             */
/*   Updated: 2023/09/06 16:21:49 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void ft_bzero(void *s, size_t n)
{
    // Call ft_memset to set 'n' bytes of memory at 's' to 0
    ft_memset(s, 0, n);
}

#include <stdio.h>
#include <string.h> // For memcmp function (used for validation)

int main() {
    char buffer[10]; // Create a character array (buffer) of size 10

    // Initialize the buffer with some data
    strncpy(buffer, "Hello,123", 9);

    // Display the original content of the buffer
    printf("Original Content: %s\n", buffer);

    // Zero out the buffer using ft_bzero
    ft_bzero(buffer, 9);

    // Display the modified content of the buffer
    printf("Modified Content: %s\n", buffer);

    // Validate if the buffer is completely zeroed out
    if (memcmp(buffer, "\0\0\0\0\0\0\0\0\0\0", 10) == 0) {
        printf("Buffer is zeroed out.\n");
    } else {
        printf("Buffer is not zeroed out.\n");
    }

    return 0;
}

/*Original Content: Hello,123
Modified Content:         
Buffer is zeroed out.
*/